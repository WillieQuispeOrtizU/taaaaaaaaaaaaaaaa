import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanLoad, CanActivate } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from '../services/user.service';

@Injectable({
    providedIn: 'root'
})
export class ActivateUserGuard implements CanLoad, CanActivate {

    constructor(private us: UserService) { }

    canLoad(): Observable<boolean> | Promise<boolean> | boolean {
        return this.us.checkUserStatus();
    }

    canActivate(): Observable<boolean> | Promise<boolean> | boolean {
        return this.us.checkUserStatus();
    }
}
