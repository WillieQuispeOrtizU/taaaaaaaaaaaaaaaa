export interface VersionAnswer {
    error: boolean;
    versionAndroid: String,
    versionIos: String,
    urlAndroid: string,
    urlIos: string
}