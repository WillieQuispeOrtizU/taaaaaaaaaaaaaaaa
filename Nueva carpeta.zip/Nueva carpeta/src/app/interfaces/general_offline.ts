export interface OfflineGeneral {
    error: boolean;
    enterprises: Enterprise[];
    categories: GeneralModel[];
    risks: GeneralModel[];
    records: Record[];
    version : Version;
    msg: string;
    default_password: boolean;
    coronaforms: any;
    covid_records: any[];
}
export interface Version {
    android: string;
    ios: string;
    link_android: string;
    link_ios : string;
}

export interface Record {
    id: number;
    project_id: string;
    project_name?: string;
    category_id: string;
    type: string;
    area: string;
    latitude: string;
    longitude: string;
    worker_fullname: string;
    worker_id_number: string;
    description?: any;
    suggestions?: any;
    boss_title: string;
    boss_signature: string;
    boss_fullname: string;
    url_img_front: string;
    url_img_back: string;
    completed: string;
    created_at: string;
    date_info: string;
    risks_list: number[];
    project: Project;
}

export interface GeneralModel {
    id: number;
    name: string;
}

export interface Enterprise {
    id: number;
    name: string;
    projects: Project[];
}

export interface Project {
    id: number;
    enterprise_id: string;
    name: string;
}