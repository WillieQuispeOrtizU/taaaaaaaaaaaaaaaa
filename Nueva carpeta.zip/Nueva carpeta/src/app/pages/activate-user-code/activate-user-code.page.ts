import { Component, OnInit, ViewChildren, QueryList, AfterViewInit } from '@angular/core';
import { LoadingService } from 'src/app/services/loading.service';
import { UserService } from 'src/app/services/user.service';
import { NavController, IonInput } from '@ionic/angular';
import { AlertController } from '@ionic/angular';

@Component({
    selector: 'app-activate-user-code',
    templateUrl: './activate-user-code.page.html',
    styleUrls: ['./activate-user-code.page.scss'],
})
export class ActivateUserCodePage implements OnInit, AfterViewInit {
    codeDigits: string[] = new Array(4).fill('');
    @ViewChildren('codeInput') codeInputs!: QueryList<IonInput>;

    constructor(
        private loading: LoadingService,
        private us: UserService,
        private navCtrl: NavController,
        private alertController: AlertController
    ) { }   

    ngOnInit() {
    }

    ngAfterViewInit() {
        setTimeout(() => {
            const inputArray = this.codeInputs.toArray();
            if (inputArray && inputArray.length > 0) {
                inputArray[0].setFocus();
            }
        }, 300);
    }

    logout() {
        this.loading.present();
        this.us.logout().subscribe(
            (data) => {
                this.loading.dismiss();
                this.us.clearAll();
                this.navCtrl.navigateRoot('/login');
            },
            (err) => {
                this.loading.dismiss();
                console.log(err);
            }
        );
    }



    onKeyPress(index: number, event: KeyboardEvent) {
        const key = event.key;
        const regex = /^[a-zA-Z0-9]$/;

        if (!regex.test(key)) {
            event.preventDefault();
            return;
        }

        event.preventDefault();

        this.codeDigits[index] = key.toUpperCase();

        if (index < this.codeDigits.length - 1) {
            setTimeout(() => {
                this.codeInputs.toArray()[index + 1].setFocus();
            }, 10);
        }
    }

    onKeyDown(index: number, event: KeyboardEvent) {
        if (event.key === 'Backspace') {
            if (!this.codeDigits[index] && index > 0) {
                this.codeDigits[index - 1] = '';
                setTimeout(() => {
                    this.codeInputs.toArray()[index - 1].setFocus();
                }, 0);
            }
            else if (this.codeDigits[index]) {
                this.codeDigits[index] = '';
                setTimeout(() => {
                    this.codeInputs.toArray()[index - 1].setFocus();
                }, 0);
            }
        }

        if (event.key === 'Delete') {
            this.codeDigits[index] = '';
        }

        if (event.key === 'ArrowLeft' && index > 0) {
            setTimeout(() => {
                this.codeInputs.toArray()[index - 1].setFocus();
            }, 0);
        }

        if (event.key === 'ArrowRight' && index < this.codeDigits.length - 1) {
            setTimeout(() => {
                this.codeInputs.toArray()[index + 1].setFocus();
            }, 0);
        }
    }


    handlePaste(event: ClipboardEvent) {
        event.preventDefault();
        const clipboardData = event.clipboardData;
        if (clipboardData) {
            const pastedText = clipboardData.getData('text').replace(/\s/g, '');

            if (/^[A-Za-z0-9]{1,4}$/.test(pastedText)) {
                this.codeDigits = new Array(4).fill('');

                for (let i = 0; i < Math.min(this.codeDigits.length, pastedText.length); i++) {
                    this.codeDigits[i] = pastedText[i].toUpperCase();
                }

                if (pastedText.length < 4) {
                    setTimeout(() => {
                        this.codeInputs.toArray()[pastedText.length].setFocus();
                    }, 10);
                }
            }
        }
    }
    async presentErrorAlert() {
        const alert = await this.alertController.create({
            header: 'Código incorrecto',
            message: 'Por favor, ingrese el código nuevamente.',
            buttons: ['Aceptar']
        });

        await alert.present();
    }
    async presentSuccessAlert() {
        const alert = await this.alertController.create({
            header: 'Código correcto',
            message: '¡Tu cuenta ha sido activada exitosamente!',
            buttons: [
                {
                    text: 'Aceptar',
                    handler: () => {
                        this.navCtrl.navigateRoot('/login');
                    }
                }
            ]
        });

        await alert.present();
    }
    verifyCode() {
        // Obtener el código ingresado por el usuario
        const enteredCode = this.codeDigits.join('');

        // Comparar el código ingresado con el activationCode
        if (enteredCode === this.us.activationCode) {
            // Mostrar alerta de éxito
            this.presentSuccessAlert();
        } else {
            // Mostrar alerta de error
            this.presentErrorAlert();
        }
        console.log('Código recibido del backend:', this.us.activationCode);
        console.log('Email recibido del backend:', this.us.activationEmail);
    }
}
