import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ActivateUserCodePage } from './activate-user-code.page';
import { ActivateUserCodePageRoutingModule } from './activate-user-code-routing.module';

const routes: Routes = [
  {
    path: '',
    component: ActivateUserCodePage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ActivateUserCodePageRoutingModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ActivateUserCodePage]
})
export class ActivateUserCodePageModule {}
