import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemperatureCardPage } from './temperature-card.page';

describe('TemperatureCardPage', () => {
  let component: TemperatureCardPage;
  let fixture: ComponentFixture<TemperatureCardPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemperatureCardPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemperatureCardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
