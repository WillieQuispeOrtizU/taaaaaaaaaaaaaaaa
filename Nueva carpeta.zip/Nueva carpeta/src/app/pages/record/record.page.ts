import { Component, OnInit, ViewChild } from '@angular/core';
import { RecordService } from 'src/app/services/record.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgSignaturePadOptions, SignaturePadComponent } from '@almothafar/angular-signature-pad';
import { LocationService } from 'src/app/services/location.service';
import { ToastController, NavController, ActionSheetController } from '@ionic/angular';
import { Camera, CameraResultType, CameraSource, ImageOptions } from '@capacitor/camera';
import { LoadingService } from 'src/app/services/loading.service';
import { Enterprise } from 'src/app/interfaces/enterprise';
import { UserService } from 'src/app/services/user.service';
import { NetworkService } from 'src/app/services/network.service';
import * as moment from 'moment';
import { AlertCtrlService } from 'src/app/services/alert-ctrl.service';
import { Observable } from 'rxjs';
import * as momentTz from 'moment-timezone';

@Component({
    selector: 'app-record',
    templateUrl: './record.page.html',
    styleUrls: ['./record.page.scss'],
})

export class RecordPage implements OnInit {

    project:any;
    enterprise:Enterprise | undefined;
    @ViewChild('signature')
    public signaturePad!: SignaturePadComponent;
    signature = '';
    isDrawing = false;
    signaturePadOptions: NgSignaturePadOptions  = {
        minWidth: 2,
        canvasWidth: window.innerWidth,
        canvasHeight: 250,
        backgroundColor: '#f6fbff',
        penColor: '#666a73'
    };
    show_extra:Boolean = true;
    reportData:any = {
        project_id : null,
        project_name: '',
        category_id: null,
        type: "",
        area: "",
        completed: "",
        risks: [],
        latitude: "",
        longitude: "",
        worker_fullname: "",
        worker_id_number: "",
        description: "",
        actions: "",
        suggestions: "",
        boss_signature: "",
        boss_fullname: "",
        url_img_front: null,
        url_img_back: null,
        boss_title: "",
        created_at: "",
        uuid: ""
    }
    risks_model: boolean[] = [];
    c_images:any = [null,null];
    flag_canvas: Boolean = false;
    record_id:any;
    edit:boolean = false;
    minDate:any;
    maxDate:any;
    size1 = 0;
    size2 = 0;
    w1 = 0;
    w2 = 0;
    h1 = 0;
    h2 = 0;
    constructor(public rs: RecordService,
                private activeRouter: ActivatedRoute,
                private router: Router,
                public ls: LocationService,
                private toastController: ToastController,
                private loading: LoadingService,
                private us: UserService,
                private navCtrl: NavController,
                private ns: NetworkService,
                private alertCtrl: AlertCtrlService,
                private actionSheetCtrl: ActionSheetController) { }

    ngOnInit() {
        this.ls.getLocation();
        this.minDate = moment().startOf('year').format('YYYY-MM-DD');
        this.maxDate = moment().format("YYYY-MM-DD");
        this.edit = false;
        this.record_id = this.activeRouter.snapshot.paramMap.get('record_id');
        if (this.record_id != "" &&  this.record_id != null)
        {
            this.edit = true;
            this.reportData = this.rs.reports[this.record_id];
            

            // Parsea la cadena en formato "YYYY-MM-DD HH:mm:ss" y ajusta la zona horaria a 'America/Lima'
            let fechaMoment = momentTz.tz(this.reportData.completed, 'America/Lima');

            // Convierte la fecha moment a un objeto Date
            let fecha = fechaMoment.toDate();

            // Obtiene los componentes individuales de la fecha
            let year = fecha.getFullYear();
            let month = fecha.getMonth() + 1; // Los meses van de 0 a 11, por eso sumamos 1
            let day = fecha.getDate();
            let hours = fecha.getHours();
            let minutes = fecha.getMinutes();
            let seconds = fecha.getSeconds();

            // Formatea la cadena manualmente en el formato deseado "YYYY-MM-DDTHH:mm:ss.000Z"
            let fechaFormateada = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}T${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.000Z`;

            // Actualiza el valor de reportData.completed
            this.reportData.completed = fechaFormateada;


            console.log("EXISTE",this.reportData)
            let enterprise_index = this.searchEnterpriseById(this.rs.enterprise_id);
            this.project = this.searchProjectById(enterprise_index,this.rs.project_id);
            this.enterprise = this.rs.enterprises[enterprise_index];
            this.fillRisks();
        } else {
            let enterprise_index = this.searchEnterpriseById(this.rs.enterprise_id);
            this.enterprise = this.rs.enterprises[enterprise_index];
            this.project = this.searchProjectById(enterprise_index,this.rs.project_id);
            this.reportData.project_id = this.rs.project_id;
            this.reportData.worker_fullname = this.us.user.name;
            this.reportData.completed = new Date().toISOString();
            this.reportData.created_at = new Date().toISOString();
            this.reportData.project_name = this.project.name;
            this.reportData.uuid = moment().unix() + "-" + this.us.user.roles[0].pivot.user_id;
        }
        console.log("COMPLETED",this.reportData.completed);

    }

    ionViewDidEnter() {
        if(!this.edit)
        {
            let t = setTimeout(() => {
                this.flag_canvas = false;
                this.signaturePad.off();
                clearTimeout(t);
            }, 200);
        }

    }

    showHideExtra(){
        this.show_extra = !this.show_extra;
    }

    searchProjectById(enterprise_index: any,project_id: any)
    {
        let projects = this.rs.enterprises[enterprise_index].projects;
        for (let index = 0; index < projects.length; index++) {
            const element = projects[index];
            if(element.id == project_id) {
                return element;
            }
        }

        return null;
    }

    searchEnterpriseById(enterprise_id: any) {
        for (let index = 0; index < this.rs.enterprises.length; index++) {
            const element = this.rs.enterprises[index];
            if (element.id == enterprise_id) {
                return index;
            }
        }

        return -1;
    }


    savePad() {
        this.reportData.boss_signature = this.signaturePad.toDataURL();
        console.log("GUARDAR PAD",this.reportData.boss_signature);
    }
     
    clearPad() {
        this.signaturePad.clear();
    }

    drawComplete(event: MouseEvent | Touch) {
        // will be notified of szimek/signature_pad's onEnd event
        console.log('Completed drawing', event);
        console.log(this.signaturePad.toDataURL());
      }
    
      drawStart(event: MouseEvent | Touch) {
        // will be notified of szimek/signature_pad's onBegin event
        console.log('Start drawing', event);
      }

    manageChk(event: any)
    {
        let d = event.detail;
        if(d.checked) {
            this.reportData.risks.push(d.value);
        } else {
            let i = this.reportData.risks.indexOf(d.value);
            if(i > -1) {
                this.reportData.risks.splice(i,1);
            }
        }
    }

    saveReport()
    {
        let c_msg = "";
        if(this.reportData.type == ""){
            c_msg += "Debes seleccionar si es seguro o inseguro. ";
        }

        if(this.reportData.category_id == null){
            c_msg += "Debes seleccionar medio ambiente, seguridad, salud o calidad. "
        }

        if(this.reportData.risks.length == 0){
            c_msg += "Debes seleccionar al menos una observación. "
        }
        /* if(this.reportData.url_img_front == null){
            c_msg += "Debes subir foto número 1. "
        }
        if(this.reportData.url_img_back == null){
            c_msg += "Debes subir foto número 2. "
        } */


        if(c_msg != ""){
            this.alertCtrl.present("JJC",c_msg);
            return;
        }

        this.savePad();
        this.reportData.latitude = this.ls.current_location.latitude;
        this.reportData.longitude = this.ls.current_location.longitude;
        console.log("REPORT DATA",this.reportData);
        this.loading.present();
        if(!this.ns.checkConnection()){  
            console.log("GUARDADO LOCALMENTE, NO HAY CONEXIÓN")
            this.rs.saveRecordLocally(this.reportData); 
            this.navCtrl.pop();
            
            this.loading.dismiss();
            return;
        }
        
        this.rs.saveReport(this.reportData)
            .subscribe(
                (data) => {
                    if(!data.error){
                        this.presentToastWithOptions();
                    } else {
                        this.alertCtrl.present("JJC",data.msg)
                    }

                    this.navCtrl.pop();
                    this.loading.dismiss();
                },
                (error) => {
                    this.rs.saveRecordLocally(this.reportData); 
                    this.navCtrl.pop();
                    
                    this.loading.dismiss();

                }
            )
        console.log("GUARDADO EN EL SERVIDOR, HAY CONEXIÓN")
        
    }

    async presentToastWithOptions() {
        const toast = await this.toastController.create({
            message: 'Registro envíado correctamente',
            position: 'bottom',
            duration: 2000
        });
        toast.present();
    }

    async presentActionSheet(type: any) {
        if (this.edit)
            return;
            
        const actionSheet = await this.actionSheetCtrl.create({
            header: 'Imagen',
            mode: 'ios',
            buttons: [{
                text: 'Tomar foto',
                handler: () => {
                    this.takePicture(1,type);
                }
            }, {
                text: 'Usar galería',
                handler: () => {
                    this.takePicture(0, type);
                }
            }, {
                text: 'Cancelar',
                icon: 'close',
                role: 'cancel',
                handler: () => {
                }
            }]
        });
        await actionSheet.present();
    }

    async takePicture(sourceType: any, type: any) {
        if(this.edit)
            return;

        const options = {
            quality: 50,
            resultType: CameraResultType.Base64,  // Similar a DATA_URL
            encodingType: 'jpeg',  // No hay un equivalente directo, pero puedes especificar la extensión en el resultType
            source: CameraSource.Prompt,  // Puedes ajustar esto según tus necesidades
            correctOrientation: true,
            allowEditing: false,        
            width: 1024,
            height: 768,
        }
        try {
            const image = await Camera.getPhoto(options);
            if (type === 1) {
              this.reportData.url_img_front = 'data:image/jpeg;base64,' + image.base64String;
            } else {
              this.reportData.url_img_back = 'data:image/jpeg;base64,' + image.base64String;
            }
            console.log("ESFFSDSDFSD")
          } catch (err) {
            console.error(err);
            alert(err)
        }
    }

    __rotateImage(degree: any,img_type: any)
    {
        let canvas = document.createElement('canvas');
        let cContext = canvas.getContext('2d');
        if (!cContext) {
            console.error("Contexto 2D no disponible");
            return;
        }
        let img = new Image();
        switch (img_type) {
            case 1:
                img.src = this.reportData.url_img_front;
                break;
            case 2:
                img.src = this.reportData.url_img_back;
                break;
            default:
                break;
        }
        let cw = img.height, ch = img.width, cx = 0, cy = img.height * (-1);

        canvas.setAttribute('width', cw+'');
        canvas.setAttribute('height', ch+'');
        cContext.rotate(degree * Math.PI / 180);
        cContext.drawImage(img, cx, cy);
        cContext.restore();
        let dimensions;
        switch (img_type) {
            case 1:
                this.reportData.url_img_front = canvas.toDataURL("image/jpeg", 100);
                this.getImageDimensions(this.reportData.url_img_front).then(
                    (data) => {
                        dimensions = data;
                        this.w1 = dimensions.width;
                        this.h1 = dimensions.height;
                    }
                );
                console.log(this.calculateImageSize(this.reportData.url_img_front))
                break;
            case 2:
                this.reportData.url_img_back = canvas.toDataURL();
                this.getImageDimensions(this.reportData.url_img_back).then(
                    (data) => {
                        dimensions = data;
                        this.w1 = dimensions.width;
                        this.h1 = dimensions.height;
                    }
                );
                console.log(this.calculateImageSize(this.reportData.url_img_back))
                break;
            default:
                break;
        }
    }

    rotateImage(degree: any,img_type: any)
    {
        let canvas = document.createElement('canvas');
        let cContext = canvas.getContext('2d');
        if (!cContext) {
            console.error("Contexto 2D no disponible");
            return;
        }
        let img = new Image();
        switch (img_type) {
            case 1:
                img.src = this.reportData.url_img_front;
                break;
            case 2:
                img.src = this.reportData.url_img_back;
                break;
            default:
                break;
        }
        let cw = img.width, ch = img.height, cx = 0, cy = 0;

        switch (degree) {
        case 90:
            cw = img.height;
            ch = img.width;
            cy = img.height * (-1);
            break;
        case 180:
            cx = img.width * (-1);
            cy = img.height * (-1);
            break;
        case 270:
            cw = img.height;
            ch = img.width;
            cx = img.width * (-1);
            break;
        }

        canvas.setAttribute('width', cw+'');
        canvas.setAttribute('height', ch+'');
        cContext.rotate(degree * Math.PI / 180);
        cContext.drawImage(img, cx, cy);
        let dimensions;
        switch (img_type) {
            case 1:
                this.reportData.url_img_front = canvas.toDataURL("image/jpeg", 100);
                // this.getImageDimensions(this.reportData.url_img_front).then(
                //     (data) => {
                //         dimensions = data;
                //         console.log(dimensions);
                //         console.log(dimensions.width);
                //         this.w1 = dimensions.width;
                //         this.h1 = dimensions.height;
                //     }
                // );
                // this.size1 = this.calculateImageSize(this.reportData.url_img_front);
                break;
            case 2:
                this.reportData.url_img_back = canvas.toDataURL("image/jpeg", 100);
                // this.getImageDimensions(this.reportData.url_img_back).then(
                //     (data) => {
                //         dimensions = data;
                //         this.w2 = dimensions.width;
                //         this.h2 = dimensions.height;
                //     }
                // );
                // this.size2 = this.calculateImageSize(this.reportData.url_img_back);
                break;
            default:
                break;
        }
    }

    clearImg(type: any)
    {
        if(type == 1)
            this.reportData.url_img_front = null;
        else
            this.reportData.url_img_back = null;
    }

    activateCanvas(type: any) {
        if (type == 1) {
            this.signaturePad.on();
            this.flag_canvas = true;
        } else {
            this.signaturePad.off();
            this.flag_canvas = false;
        }
    }

    getDetail() {
        let data = {
            record_id : this.record_id
        }
        this.loading.present();
        this.rs.getDetail(data)
            .subscribe(
                (data) => {
                    this.loading.dismiss();
                    this.reportData = data.record;
                    this.project = data.record.project;
                    let enterprise_index = this.searchEnterpriseById(this.project.enterprise_id);
                    this.enterprise = this.rs.enterprises[enterprise_index];
                    this.fillRisks();
                    
                },
                (err) => {
                    this.loading.dismiss();
                    console.log(err);
                }
            )
    }

    fillRisks() {
        for (let index = 0; index < this.rs.risks.length; index++) {
            const element = this.rs.risks[index];

            this.risks_model[index] = false;

            if(!this.reportData.created_at) {
                if (this.reportData.risks_list.includes(element.id)){
                    this.risks_model[index] = true;
                }
            } else {
                if (this.reportData.risks.includes(element.id + '')){
                    this.risks_model[index] = true;
                }                
            }
        }

    }

    getImageDimensions(file: any): Promise<{ width: number; height: number }> {
        return new Promise((resolve, reject) => {
            const image = new Image();
            image.onload = () => {
                resolve({ width: image.width, height: image.height });
            };
            image.onerror = (error) => {
                reject(error);
            };
            image.src = file;
        });
    }
    

    base64ToFile(_base64: any,name: any)
    {   
        fetch(_base64)
            .then(res => res.blob())
            .then(blob => {
                // const file = new File([blob], "File name")
                return new File([blob],name);
            })
    }

    calculateImageSize(base64String: any) {
        let padding, inBytes, base64StringLength;
        if (base64String.endsWith("==")) padding = 2;
        else if (base64String.endsWith("=")) padding = 1;
        else padding = 0;

        base64StringLength = base64String.length;
        // console.log(base64StringLength)
        inBytes = (base64StringLength / 4) * 3 - padding;
        // console.log(inBytes);
        return inBytes / 1000;
    }
}
