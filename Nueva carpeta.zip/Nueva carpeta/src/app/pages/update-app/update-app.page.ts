import { Component, OnInit } from '@angular/core';
import { Platform, NavController } from '@ionic/angular';
/* import { InAppBrowser } from '@ionic-native/in-app-browser/ngx'; */
import { Browser } from '@capacitor/browser';
import { VersionService } from 'src/app/services/version.service';

@Component({
    selector: 'app-update-app',
    templateUrl: './update-app.page.html',
    styleUrls: ['./update-app.page.scss'],
})
export class UpdateAppPage implements OnInit {

    constructor(private platform: Platform,
                private vs: VersionService,
                private navCtrl: NavController) { }

    ngOnInit() {
    }

    ionViewDidEnter() {
        this.checkVersion();
    }

    doRefresh(event: any) {
    
        this.checkVersion(event);

    }

    checkVersion(event?: any) {
        const flag = this.vs.checkCurrentVersion(1);
        flag.then(
            (data) => {
                if(data)
                {
                    this.navCtrl.navigateRoot('pre-main');
                }

                if(event)
                    event.target.complete();
            }
        )
    }


    async goStore()
    {
        if(this.platform.is("android")) {
            window.open(this.vs.link_android, "_system");
            // const browser = this.iab.create(this.rs.version.link_android);
        } else {
            Browser.open({ url: this.vs.link_ios });
            /* const browser = this.iab.create(this.vs.link_ios); */
        }
    }
}
