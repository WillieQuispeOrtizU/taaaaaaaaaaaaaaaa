import { Component, OnInit } from '@angular/core';
import { CoronaService } from 'src/app/services/corona.service';
import { LoadingService } from 'src/app/services/loading.service';
import { CardInformation } from 'src/app/interfaces/card';
import { Location } from '@angular/common';
import { NavController } from '@ionic/angular';

@Component({
    selector: 'app-corona-card',
    templateUrl: './corona-card.page.html',
    styleUrls: ['./corona-card.page.scss'],
})
export class CoronaCardPage implements OnInit {

    cardData: CardInformation | undefined;
    constructor(private cs: CoronaService,
                private loading: LoadingService,
                private location: Location,
                private navCtrl: NavController) { }

    ngOnInit() {
        this.getInformation();
    }

    getInformation() {
        this.loading.present();
        this.cs.getCardData()
            .subscribe(
                (data) => {
                    this.loading.dismiss();
                    this.cardData = data.cardData;
                },
                (err) => {
                    this.loading.dismiss();
                }
            )
    }

    returnBack() {
        // this.location.back();
        this.navCtrl.navigateRoot('/main');
    }

}
