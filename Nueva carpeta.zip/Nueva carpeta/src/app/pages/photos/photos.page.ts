import { Component, OnInit, ViewChild } from '@angular/core';
import { LoadingController, ActionSheetController, ToastController } from '@ionic/angular';
import { Camera, CameraResultType, CameraSource, ImageOptions } from '@capacitor/camera';

import { RecordService } from 'src/app/services/record.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CropperComponent } from 'angular-cropperjs';
import { NetworkService } from 'src/app/services/network.service';

@Component({
    selector: 'app-photos',
    templateUrl: './photos.page.html',
    styleUrls: ['./photos.page.scss'],
})
export class PhotosPage implements OnInit {
    
    @ViewChild('angularCropper')
    public angularCropper: CropperComponent = new CropperComponent;
    cropperOptions: any;
    croppedImage: string | null = null;

    myImage = null;
    scaleValX = 1;
    scaleValY = 1;

    url_img_front:string = "";
    url_img_back:string = "";
    project_id!: string;
    loading:any;
    sending: Boolean = false;
    internet: Boolean = false;
    constructor(private loadingController: LoadingController,
                private actionSheetController: ActionSheetController,
                private rs: RecordService,
                private router: Router,
                private activeRouter: ActivatedRoute,
                private toastController: ToastController,
                private ns: NetworkService) {

        this.cropperOptions = {
            dragMode: 'none',
            aspectRatio: 1,
            autoCrop: false,
            movable: false,
            zoomable: false,
            scalable: false,
            autoCropArea: 0,
        };
    }

    ionViewDidEnter() {
        this.internet = this.ns.checkConnection();
        this.project_id = this.rs.project_id;
        this.takePicture(1,1);
    }

    ngOnInit() {
        
    }

    clearImg(type: any)
    {
        if(type == 1)
            this.url_img_front = "";
        else
            this.url_img_back = "";
    }

    async presentActionSheet() {
        let opts: never[] = [];
        const actionSheet = await this.actionSheetController.create({
            header: 'Foto',
            mode: 'ios',
            buttons: opts
        });

        await actionSheet.present();
    }

    async takePicture(sourceType: any, type: any) {
        const options = {
            quality: 50,
            resultType: CameraResultType.Base64,  // Similar a DATA_URL
            encodingType: 'jpeg',  // No hay un equivalente directo, pero puedes especificar la extensión en el resultType
            source: CameraSource.Prompt,  // Puedes ajustar esto según tus necesidades
            correctOrientation: true,
            allowEditing: false,
            width: 1536,
            height: 2048,
          };

        try {
            const image = await Camera.getPhoto(options);
        
            if (type === 1) {
              this.url_img_front = 'data:image/jpeg;base64,' + image.base64String;
              if (this.url_img_back === "") {
                await this.takePicture(1, 2);
              }
            } else {
              this.url_img_back = 'data:image/jpeg;base64,' + image.base64String;
            }
          } catch (err) {
            console.error(err);
            alert(JSON.stringify(err))
          }
    }

    sendImage()
    {
        if(this.sending)
            return;
            
        let promises = [];

        this.presentLoading();
        this.sending = true;
        this.rs.sendImageWatcher(this.url_img_front,this.url_img_back,this.project_id)
                        .subscribe(
                            (data) => {
                                this.sending = false;
                                this.loading.dismiss();
                                this.url_img_front = "";
                                this.url_img_back = "";
                                this.presentToastWithOptions();
                                this.router.navigate(['main']);
                            },
                            (error) => {
                                this.sending = false;
                                this.loading.dismiss();
                                alert(JSON.stringify(error));
                            }
                        );
    }

    async presentToastWithOptions() {
        const toast = await this.toastController.create({
            message: 'Imagenes envíadas correctamente',
            position: 'bottom',
            duration: 2000
        });
        toast.present();
    }

    saveCropped() {
        let croppedImgB64String: string = this.angularCropper.cropper.getCroppedCanvas().toDataURL('image/jpeg', (100 / 100));
        this.croppedImage = croppedImgB64String;
        this.url_img_front = croppedImgB64String;
    }

    async presentLoading() {
        this.loading = await this.loadingController.create({
            message: 'Cargando...',
            mode: 'md'
            // duration: 2000
        });
        await this.loading.present();
    
        const { role, data } = await this.loading.onDidDismiss();
    }

    rotateImage(degree: any,img_type: any) {
        let canvas = document.createElement('canvas');
        let cContext = canvas.getContext('2d');
        if (!cContext) {
            console.error("Contexto 2D no disponible");
            return;
        }
        let img = new Image();
        switch (img_type) {
            case 1:
                img.src = this.url_img_front;
                break;
            case 2:
                img.src = this.url_img_back;
                break;
            default:
                break;
        }
        let cw = img.width, ch = img.height, cx = 0, cy = 0;

        switch (degree) {
        case 90:
            cw = img.height;
            ch = img.width;
            cy = img.height * (-1);
            break;
        case 180:
            cx = img.width * (-1);
            cy = img.height * (-1);
            break;
        case 270:
            cw = img.height;
            ch = img.width;
            cx = img.width * (-1);
            break;
        }

        canvas.setAttribute('width', cw+'');
        canvas.setAttribute('height', ch+'');
        cContext.rotate(degree * Math.PI / 180);
        cContext.drawImage(img, cx, cy);
        switch (img_type) {
            case 1:
                this.url_img_front = canvas.toDataURL("image/jpeg", 100);
                break;
            case 2:
                this.url_img_back = canvas.toDataURL("image/jpeg", 100);
                break;
            default:
                break;
        }
    }

}
