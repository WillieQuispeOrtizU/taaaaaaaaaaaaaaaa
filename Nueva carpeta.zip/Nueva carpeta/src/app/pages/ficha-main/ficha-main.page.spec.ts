import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FichaMainPage } from './ficha-main.page';

describe('FichaMainPage', () => {
  let component: FichaMainPage;
  let fixture: ComponentFixture<FichaMainPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FichaMainPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FichaMainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
