import { Component, OnInit, ViewChild, Inject, ElementRef } from '@angular/core';
import * as moment from 'moment-timezone';
import { IonicSlides , NavController, ToastController, ModalController, IonContent } from '@ionic/angular';
import { Location } from '@angular/common';
import { CoronaService } from 'src/app/services/corona.service';
import { LoadingService } from 'src/app/services/loading.service';
import { RecordService } from 'src/app/services/record.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LocationService } from 'src/app/services/location.service';
import { AlertCtrlService } from 'src/app/services/alert-ctrl.service';
import { TermsPage } from '../terms/terms.page';
import { NgSignaturePadOptions, SignaturePadComponent } from '@almothafar/angular-signature-pad';
import * as momentTz from 'moment-timezone';

import { Browser } from '@capacitor/browser';
/* import { InAppBrowser } from '@ionic-native/in-app-browser/ngx'; */
import { SwiperOptions } from 'swiper/types';
import Swiper from 'swiper'


@Component({
    selector: 'app-corona',
    templateUrl: './corona.page.html',
    styleUrls: ['./corona.page.scss'],
})
export class CoronaPage implements OnInit {

    fields = {
        children:'',
        id :null,
        fullname: '',
        enterprise_name: '',
        enterprise_ruc: '',
        project: '',
        work_area: '',
        document_type: '',
        document: '',
        birthday: '',
        age: '',
        address: '',
        cellphone: '',
        current_date: '',
        signature: '',
        flag_terms: 0,
        question_1_prev: '',
        question_1: [] as any[],
        question_1_11_1: '',
        question_1_11_2:'',
        question_1_11_3:'',
        question_2: '',
        question_3: '',
        question_3_1: '',
        question_4: '',
        question_5: '',
        question_6: '',
        question_7: '',
        question_7_1: '',
        question_7_2: '',
        question_8: '',
        question_8_1: '',
        question_9: '',
        question_10_prev: '',
        question_10: [] as any[],
        question_10_3_1: '',
        question_10_6_1: '',
        question_10_8_1: '',
        question_10_9_1: '',
        latitude: 0,
        longitude: 0,
        daily_question_1_prev: '',
        daily_question_1: [] as any[],
        daily_question_1_11_1: '',
        daily_question_2: '',
        daily_question_3: [] as any[],
        question_12: [] as any[],
        question_2_1_1 :'',
        question_2_1_2 :''
    }
    touchStartX: number = 0;
    touchStartY: number = 0;

    symptoms = [
        "Sensación de alza térmica o fiebre",
        "Tos, estornudos o dificultad para respirar",
        "Expectoración o flema amarilla verdosa ",
        "Congestión o secreción nasal",
        "Dolor de garganta",
        "Pérdida de olfato, náusea o diarrea",      
        "Dolor en el pecho",
        "Desorientación o confusión",
        "Coloración azul en los labios",
        "Otros"
    ];
    problems = [
        "Edad mayor de 65 años",
        "Hipertensión arterial , refractaria",
        "Enfermedad cardiovascular (especificar en caso marque Si)",
        "Diabetes mellitus",
        "Obesidad con IMC de 40 a más",
        "Asma o enfermedad respiratoria crónica (detallar en caso marque Si)",
        "Insuficiencia renal crónica",
        "Enfermedad o tratamiento inmunodepresor (detallar en caso marque Si)",
        "Cancer, otros (especificar en caso marque Si)"
    ];
    types_job = [
        "Presencial",
        "Remota",
        "Semipresencial"       
    ];
    slideOpts: SwiperOptions = {
        /* initialSlide: 2, */
        speed: 400,
        allowSlideNext: true,
        allowSlidePrev: true,
        observer: true,
        observeParents: true,
        parallax:true,
        on: {
            transitionEnd: (event) => {
              this.swiperEvent(event);
            },
          },
    };
    swiper: Swiper | undefined;

    @ViewChild('swiper') 
    swiperRef: ElementRef | undefined;
    slides?: Swiper;

    slide_index = 0;
    slide_limit = 4;

    @ViewChild('signature') 
    public signaturePad!: SignaturePadComponent;
    signature = '';
    isDrawing = false;
    public signaturePadOptions: NgSignaturePadOptions  = {
        minWidth: 2,
        canvasWidth: window.innerWidth - 50,
        canvasHeight: 250,
        backgroundColor: '#f6fbff',
        penColor: '#666a73'
    };
    flag_canvas: Boolean = false;
    edit: Boolean = false;
    private originalSwiper: Swiper | undefined;

    @ViewChild(IonContent) content!: IonContent;
    constructor(private location: Location,
                private cs: CoronaService,
                private loading: LoadingService,
                private rs: RecordService,
                private router: Router,
                private navCtrl: NavController,
                private toastCtrl: ToastController,
                private ls: LocationService,
                private alertCtrl: AlertCtrlService,
                private modalCtrl: ModalController,
                private activeRouter: ActivatedRoute,
) { }

    swiperReady(){
        console.log("READY?")
        this.slides = this.swiperRef?.nativeElement.swiper;
        if (this.swiperRef?.nativeElement.swiper) {
            this.swiperRef.nativeElement.swiper.allowTouchMove = false;
            console.log('swiperReady: ',this.swiperRef?.nativeElement.swiper)
            console.log('swiperReady allowTouchMove: ',this.swiperRef?.nativeElement.swiper.allowTouchMove)
        }

        if (this.slides) {
            this.slides.allowTouchMove = false;
        }
    }
    swiperEvent(event: any): void {
        console.log('swiperEvent: ',event)
        if (event.transition === 'slide') {
            console.log("SE SLIDEO")
          this.updateHeight();
        }
      }
    swiperInit(swiper: any) {
        console.log("INITCONSOLEATE PORFA")
        this.swiper = swiper;
    
        
    }
    initSwiper() {
        // Almacena una referencia al swiper original
        this.originalSwiper = this.swiperRef?.nativeElement.swiper;
    
        // Destruye el swiper actual si existe
        if (this.originalSwiper) {
          this.originalSwiper.destroy(true, true);
        }
    
        // Crea un nuevo swiper con la configuración actual y la referencia al swiper original
        if (this.swiperRef) {
            this.swiperRef.nativeElement.swiper = new Swiper(this.swiperRef.nativeElement, this.slideOpts);
        }
      }
    swiperSlideChanged(e: any){
        console.log('changed: ',e)
    }
    ngOnInit() {
        this.ls.getLocation();
        this.slides?.update(); // Actualizar diapositivas después de cargar datos si es necesario


        let current_id = this.activeRouter.snapshot.paramMap.get('corona_id');
        if(current_id)
        {
            console.log('144')
            let current_form = this.rs.covid_records.find(record => record.id == current_id);
            console.log('146',current_form);
            this.fields = current_form;
            console.log("EXISTE",this.fields);
            // Supongamos que "01-02-2024 09:21 am" está en 'America/Lima'
            let fechaMoment = momentTz.tz(this.fields.current_date, 'DD-MM-YYYY hh:mm a', 'America/Lima');

            // Obtiene los componentes individuales de la fecha
            let year = fechaMoment.year();
            let month = fechaMoment.month() + 1; // Los meses van de 0 a 11, por eso sumamos 1
            let day = fechaMoment.date();
            let hours = fechaMoment.hours();
            let minutes = fechaMoment.minutes();
            let seconds = fechaMoment.seconds();

            // Formatea la cadena manualmente en el formato deseado "YYYY-MM-DDTHH:mm:ss.000Z"
            let fechaFormateada = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}T${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.000Z`;

            // Actualiza el valor de this.fields.current_date
            this.fields.current_date = fechaFormateada;
            console.log("TOISOSTRING CURRENT DATE",this.fields);
            return;
        }


        let c_date = new Date().toISOString();
        this.fields.current_date = c_date;
        if(this.rs.corona_data.fullname == '' || JSON.stringify(this.rs.corona_data) == '{}') {
            this.navCtrl.pop();
            return;
        }

        this.fields.fullname = this.rs.corona_data.fullname;
        // this.fields.project = this.rs.corona_data.project;
        this.fields.cellphone = this.rs.corona_data.cellphone;
        this.fields.address = this.rs.corona_data.address;
        this.fields.flag_terms = this.rs.corona_data.flag_terms;
        // this.fields.enterprise_name = this.rs.corona_data.enterprise_name;
        // this.fields.enterprise_ruc = this.rs.corona_data.enterprise_ruc;
        this.fields.work_area = this.rs.corona_data.work_area;
        this.fields.document_type = this.rs.corona_data.document_type;
        this.fields.document = this.rs.corona_data.document;
        this.fields.birthday = this.rs.corona_data.birthday;
        this.fields.age = this.rs.corona_data.age;
        this.fields.signature = this.rs.corona_data.signature;

        this.fields.question_7 = this.rs.corona_data.question_7;
        this.fields.question_7_1 = this.rs.corona_data.question_7_1;
        this.fields.question_7_2 = this.rs.corona_data.question_7_2 == null ? '' : this.rs.corona_data.question_7_2;
        this.fields.question_10 = this.rs.corona_data.question_10;
        this.fields.question_10_3_1 = this.rs.corona_data.question_10_3_1;
        this.fields.question_10_6_1 = this.rs.corona_data.question_10_6_1;
        this.fields.question_10_8_1 = this.rs.corona_data.question_10_8_1;
        this.fields.question_10_9_1 = this.rs.corona_data.question_10_9_1;
        console.log('linea 179 ',this.fields);
        console.log('linea 180 ',this.rs.corona_data);
        this.filledProjectEnterprise();
        if(this.fields.question_10.length > 0)
        {
            this.fields.question_10_prev = "1";
        } else {
            // this.fields.question_10_prev = "0";
        }

    }
    
    ionViewDidEnter() {
        console.log('linea 179 ',this.fields);
        console.log('linea 180 ',this.rs.corona_data);
        this.swiperRef?.nativeElement.addEventListener('touchstart', (e: TouchEvent) => {
            this.touchStartX = e.touches[0].clientX;
          });
          
          this.swiperRef?.nativeElement.addEventListener('touchmove', (e: TouchEvent) => {
            const touchEndX = e.touches[0].clientX;
          
            const deltaX = touchEndX - this.touchStartX;
          
            // Configura un umbral para determinar si el desplazamiento es vertical
            const verticalThreshold = 10;
          
            if (Math.abs(deltaX) > verticalThreshold) {
                e.preventDefault();
            }
          });
        /* if (this.swiperRef) {
            console.log("ASIGNADO CONFIG")
            this.initSwiper();

          } */
        
        /* if (this.swiperRef) {
            this.swiperRef.swiper = new Swiper(this.swiperRef.el, {
              ...this.slideOpts,
              allowSlideNext: true,  
              on: {
                ...this.slideOpts?.on,
                transitionEnd: this.swiperEvent.bind(this),
              },
            });
          } */

          /* if (this.swiperRef) {
            this.swiperRef.nativeElement.swiper = new Swiper(this.swiperRef.nativeElement, {
              ...this.slideOpts,
              allowSlideNext: true,  // Asegúrate de agregar esta línea
              on: {
                ...this.slideOpts?.on,
                // Evento transitionEnd para el nuevo swiper
                transitionEnd: this.swiperEvent.bind(this),
              },
            });
          } */

          /* if (this.swiperRef) {
            this.swiperRef.swiper = new Swiper(this.swiperRef.el, {
              ...this.slideOpts,
              allowSlideNext: true,
              on: {
                ...this.slideOpts?.on,
                touchStart: () => {
                  // Deshabilita la capacidad de deslizamiento al tocar
                  console.log("TOUCH START")
                  this.swiperRef.nativeElement.swiper.allowTouchMove = false;
                },
                touchEnd: () => {
                  // Vuelve a habilitar la capacidad de deslizamiento después de tocar
                  console.log("TOUCH END")
                  this.swiperRef.nativeElement.swiper.allowTouchMove = true;
                },
                transitionEnd: this.swiperEvent.bind(this),
              },
            });
          } */
          
        if(this.fields.signature == '' || this.fields.signature == null)
        {
            this.signaturePad.off();
            this.flag_canvas = false;
        }
    }


    deltaDate(input: any, days: any, months: any, years: any) {
        var date = new Date(input);
        date.setDate(date.getDate() + days);
        date.setMonth(date.getMonth() + months);
        date.setFullYear(date.getFullYear() + years);
        return date.toISOString();
    }

    cleanSymptoms() {
        if(this.fields.question_1_prev == '0'){
            this.fields.question_1 = [];
            this.fields.question_1_11_2 = '';
            this.fields.question_1_11_3 = '';
        }
    }

    cleanSymptomsDaily() {
        if(this.fields.daily_question_1_prev == '0'){
            this.fields.daily_question_1 = [];
        }
    }

    cleanRisks() {
        if(this.fields.question_10_prev == '0'){
            this.fields.question_10 = [];
        }
    }

    getAge(dateString: any) {
        var today = new Date();
        var birthDate = new Date(dateString);
        var age = today.getFullYear() - birthDate.getFullYear();
        var m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        this.fields.age = age + '';
        // return age;
    }

    changeSlide(type: any) {
        if(type == 1){
            if(!this.fields["id"]) {
                if (!this.fields.flag_terms) {
                    this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes aceptar los términos y condiciones");
                    return;
                }
                if (this.fields.signature == '') {
                    this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes poner tu firma");
                    return;
                }
                if(this.slide_index == 1) {

                    if (this.fields.question_10_prev == '1' && this.fields.question_10.length == 0) {
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes seleccionar al menos un factor de riesgo");
                        return;
                    } else if(this.fields.question_10_prev == '1' && this.fields.question_10.length > 0 && this.fields.question_10.indexOf('opt_3') > -1 && this.fields.question_10_3_1 == ''){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes detallar la enfermedad cardiovascular");
                        return;
                    } else if(this.fields.question_10_prev == '1' && this.fields.question_10.length > 0 && this.fields.question_10.indexOf('opt_6') > -1 && this.fields.question_10_6_1 == ''){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes detallar la enfermedad respiratoria crónica");
                        return;
                    } else if(this.fields.question_10_prev == '1' && this.fields.question_10.length > 0 && this.fields.question_10.indexOf('opt_8') > -1 && this.fields.question_10_8_1 == ''){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes detallar la enfermedad o tratamiento inmunodepresor");
                        return;
                    }else if(this.fields.question_10_prev == '1' && this.fields.question_10.length > 0 && this.fields.question_10.indexOf('opt_9') > -1 && this.fields.question_10_9_1 == ''){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes detallar otros factores de riesgos");
                        return;
                    }

                    
                    if (this.fields.question_7_1 == '') {
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes indicar tu peso");
                        return;
                    } else if (isNaN(Number(this.fields.question_7_1)) || !this.fields.question_7_1 || this.fields.question_7_1.indexOf('e') > -1 ){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Escriba un peso válido");
                        return;
                    }
        
                    if (this.fields.question_7_2 == '') {
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes indicar tu talla");
                        return;
                    } else if (isNaN(Number(this.fields.question_7_2)) || !this.fields.question_7_2 ||this.fields.question_7_2.indexOf('e') > -1 ){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Escriba una talla válida");
                        return;
                    }
    
                    if (this.fields.question_7_2.indexOf('.') > -1 || this.fields.question_7_2.indexOf(',') > -1 ) {
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes indicar tu talla pero en centímetros");
                        return;
                    }
                } else if(this.slide_index == 2) {
                    if(this.fields.daily_question_1_prev == '')
                    {
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 1.");
                        return true;
                    } else if(this.fields.daily_question_1_prev == '1' && this.fields.daily_question_1.length == 0){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes marcar algún síntoma.");
                        return true;
                    }  else if(this.fields.daily_question_3.length == 0){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes marcar tu modalidad de trabajo.");
                        return true;
                    } else if(this.fields.daily_question_1_prev == '1' && this.fields.daily_question_1.length > 0 && this.fields.daily_question_1.indexOf('opt_10') > -1 && this.fields.daily_question_1_11_1 == ''){
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes detallar los otros síntomas.");
                    }
    

                    if(this.fields.daily_question_2 == '')
                    {
                        this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 2.");
                        return true;
                    }
                    
                    //this.fields.question_1_prev = this.fields.daily_question_1_prev;
                    //this.fields.question_1 = this.fields.daily_question_1;
                    //this.fields.question_1_11_1 = this.fields.daily_question_1_11_1;
                    //this.fields.question_2 = this.fields.daily_question_2;
                    this.fields.question_12 = this.fields.daily_question_3;
                }
            }
            

            this.slide_index++;
            if (this.swiperRef) {
                console.log("DEBIO CAMBIAR")
                this.swiperRef.nativeElement.swiper.slideNext(400);
                console.log("CONFIGS", this.swiperRef.nativeElement.swiper)
            }
            let t = setTimeout(
                () => {
                    this.content.scrollToTop(500);
                    clearTimeout(t);
                },
                250
                )
/*                 this.updateHeight();
 */        } else {
            this.slide_index--;
            if (this.swiperRef) {
                console.log("DEBIO CAMBIAR")
                this.swiperRef.nativeElement.swiper.slidePrev(400);
            }
            let t = setTimeout(
                () => {
                    this.content.scrollToTop(500);
                    clearTimeout(t);
                },
                250
            )
        }
        
        return; // Add this line to fix the problem
    }


    async submit() {
        // const r = await this.checkQuestionRequired();
        // alert("ENVIAR");
        // return;
        this.fields.latitude = this.ls.current_location.latitude;
        this.fields.longitude = this.ls.current_location.longitude;

        const r = await this.checkQuestionRequired();
        if(r) {
            return;
        }

        let sending_data = JSON.parse(JSON.stringify(this.fields));
        // if(sending_data.1 == "0")
        // {
        //     sending_data.question_3 = ["opt_0"];
        // }
        if(sending_data.question_1_prev == "1")
        {
            sending_data.question_1.push("opt_0");
            delete sending_data["question_1_prev"];
        }
        delete sending_data.question_3_prev;
        console.log(sending_data);
        this.loading.present();
        this.cs.sendData(sending_data)
            .subscribe(
                (data) => {
                    console.log(data);
                    this.loading.dismiss();
                    if(!data.error) {
                        // this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo", "Gracias por contribuir con la prevención");
                        // this.returnBack();
                        this.navCtrl.navigateRoot('/corona-card');
                    }
                },
                (err) => {
                    this.loading.dismiss();
                    console.log(err);
                }
            )
    }

    manageChk(event: any) {
        let detail = event.detail;
        let value = detail.value;
        if (detail.checked) {
            this.fields.question_1.push(value);
        } else {
            let i = this.fields.question_1.indexOf(value);
            if (i > -1) {
                this.fields.question_1.splice(i, 1);
            }
        }
        this.updateHeight();
    }

    manageChkDaily(event: any) {
        console.log('407');
        let detail = event.detail;
        let value = detail.value;
        if (detail.checked) {
            this.fields.daily_question_1.push(value);
        } else {
            let i = this.fields.daily_question_1.indexOf(value);
            if (i > -1) {
                this.fields.daily_question_1.splice(i, 1);
            }
        }
        this.updateHeight();
    }
     manageChkWorkDaily(event: any) {
        let detail = event.detail;
        let value = detail.value;
    
        if (detail.checked) {
            this.fields.daily_question_3 = [];
            this.fields.daily_question_3.push(value);
        } else {
            let i = this.fields.daily_question_3.indexOf(value);
            if (i > -1) {
                this.fields.daily_question_3.splice(i, 1);
            }
        }
        this.updateHeight();
    }

    manageChkProblems(event: any) {
        let detail = event.detail;
        let value = detail.value;
        if (detail.checked) {
            this.fields.question_10.push(value);
        } else {
            let i = this.fields.question_10.indexOf(value);
            if (i > -1) {
                this.fields.question_10.splice(i, 1);
            }
        }
        this.updateHeight();
    }
    
    manageQuestion2() {
        if(this.fields.question_2 == '0'){
            this.fields.question_2_1_1 = '';
            this.fields.question_2_1_2 = '';
        }
        this.updateHeight();
    }
    manageQuestion3() {
        if(this.fields.question_3 == '0'){
            this.fields.question_3_1 = '';
        }
        this.updateHeight();
    }
    
    manageQuestion8() {
        if(this.fields.question_8 == '0'){
            this.fields.question_8_1 = '';
        }
        this.updateHeight();
    }

    returnBack() {
        this.location.back();
    }

    updateHeight() {
        console.log("ACTUALIZAR height")

        /* let t = setTimeout(
            () => {
                this.swiperRef?.nativeElement.swiper.updateAutoHeight(200);
                clearTimeout(t);
            },
            250
        ); */
    }

    async presentToastWithOptions() {
        const toast = await this.toastCtrl.create({
            message: 'Registro envíado correctamente',
            position: 'bottom',
            duration: 2000
        });
        toast.present();
    }

    async termsLegal() {
        const modal = await this.modalCtrl.create({
            component: TermsPage,
        });
        await modal.present();
    }

    prevQuestion3(event: any) {
        let v = event.detail.value;

        if(v == "0") {
            //Limpiar checkboxes
            this.fields.question_1 = [];
        }
    }

    async checkQuestionRequired() {
        if(this.fields.question_1_prev == '')
        {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 1.");
            return true;
        } else if(this.fields.question_1_prev == '1' && this.fields.question_1.length == 0){
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes marcar algún síntoma.");
            return true;
        } else if (
            this.fields.question_1_prev == '1' &&
            this.fields.question_1.length > 0 &&
            (this.fields.question_1 as string[]).indexOf('opt_10') > -1 &&
            this.fields.question_1_11_1 == ''
        ) {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo", "Debes detallar los otros síntomas.");
        }

        if(this.fields.question_2 == '')
        {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 2.");
            return true;
        }

        if(this.fields.question_3 == '')
        {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 3.");
            return true;
        } else if(this.fields.question_3 == '1' && this.fields.question_3_1 == ''){
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder el detalle de la pregunta 3.");
            return true;
        }

        if(this.fields.question_4 == '')
        {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 4.");
            return true;
        }

        if(this.fields.question_5 == '')
        {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 5.");
            return true;
        }

        if(this.fields.question_8 == '')
        {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 7.");
            return true;
        } else if(this.fields.question_8 == '1' && this.fields.question_8_1 == ''){
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder el detalle de la pregunta 7.");
            return true;
        }

        if(this.fields.question_9 == '')
        {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes responder la pregunta 8.");
            return true;
        }


        return false;
    }

    calculateIMC() {
        let weight = this.fields.question_7_1;
        let height = this.fields.question_7_2;

        if( (weight == '' || height == '') || ( isNaN(Number(weight)) || isNaN(Number(height)) ) ) {
            this.fields.question_7 = '0';
            return;
        }

        let h = Number(height) / 100;
        let w = Number(weight);
        this.fields.question_7 = ((w/(h * h))).toFixed(2) + '';
    }



    //CANVAS

    savePad() {
        this.fields.signature = this.signaturePad.toDataURL();
        // console.log(this.reportData.boss_signature);
    }

    activateCanvas(type: any) {
        if (type == 1) {
            this.signaturePad.on();
            this.flag_canvas = true;
        } else {
            this.signaturePad.off();
            this.flag_canvas = false;
        }
    }
     
    clearPad() {
        this.signaturePad.clear();
    }


    filledProjectEnterprise() {
        let enterprise_index = this.rs.enterprises.findIndex((obj: { id: any; }) => obj.id == this.rs.enterprise_id);
        let enterprise = this.rs.enterprises[enterprise_index];
        let project = enterprise.projects.find((obj: { id: any; }) => obj.id == this.rs.project_id);

        this.fields.project = project.name;
        this.fields.enterprise_name = enterprise.name;
        this.fields.enterprise_ruc = enterprise.ruc;
    }

    async openReference() {
        await Browser.open({ url: 'https://www.gob.pe/institucion/minsa/campañas/699-conoce-que-es-el-coronavirus-covid-19' });
        /* const browser = this.iab.create("https://www.gob.pe/institucion/minsa/campañas/699-conoce-que-es-el-coronavirus-covid-19"); */
    }

}
