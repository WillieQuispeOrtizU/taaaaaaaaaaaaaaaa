import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { MainPage } from './main.page';
import { ComponentsModule } from 'src/app/components/components.module';
import { MainPageRoutingModule } from './main-routing.module';

/* const routes: Routes = [
    {
        path: '',
        component: MainPage
    }
]; */

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        /* RouterModule.forChild(routes), */
        ComponentsModule,
        MainPageRoutingModule
    ],
    declarations: [MainPage]
})
export class MainPageModule { }
