import { Component } from '@angular/core';
import { register } from 'swiper/element/bundle';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, StatusBarStyle, Style } from '@capacitor/status-bar';

register();

@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html'
})
export class AppComponent {
    constructor(
        private platform: Platform,
    ) {
        this.initializeApp();
    }

    initializeApp() {
        this.platform.ready().then(() => {
            console.log("INICIAAAAR")
            StatusBar.setStyle({ style: StatusBarStyle.Default }); // Ajusta el estilo según tus necesidades
            SplashScreen.hide(); // Utiliza SplashScreen.hide() en lugar de this.splashScreen.hide()
            // let BuildInfo = (<any>window).BuildInfo;
            // alert(JSON.stringify(BuildInfo.version));
            console.log("SE INICIO?")
        });
        console.log("PROBANDO")
    }
}
