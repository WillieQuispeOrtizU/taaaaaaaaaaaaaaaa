import { Component, OnInit, ViewChild } from '@angular/core';
import { RecordService } from 'src/app/services/record.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SignaturePadComponent } from '@almothafar/angular-signature-pad';
import { LocationService } from 'src/app/services/location.service';
import { ToastController, NavController, ActionSheetController } from '@ionic/angular';
import { LoadingService } from 'src/app/services/loading.service';
import { Enterprise } from 'src/app/interfaces/enterprise';
import { UserService } from 'src/app/services/user.service';
import { NetworkService } from 'src/app/services/network.service';
import * as moment from 'moment';
import { AlertCtrlService } from 'src/app/services/alert-ctrl.service';
import { Observable } from 'rxjs';
import { CoronaService } from '../../services/corona.service';

@Component({
  selector: 'app-temperature-card',
  templateUrl: './temperature-card.page.html',
  styleUrls: ['./temperature-card.page.scss'],
})
export class TemperatureCardPage implements OnInit {
  reportData:any = {  
    temperature: 36.5,
    date_register  :null
  
  }
  project:any;
  enterprise:Enterprise | undefined;
  constructor(public rs: RecordService, 
    public ls: LocationService,
    private loading: LoadingService,
    private toastController: ToastController,
    private navCtrl: NavController,
    private us: UserService,
    private alertCtrl: AlertCtrlService,
   private cs : CoronaService) { }

  ngOnInit() {
    let enterprise_index = this.searchEnterpriseById(this.rs.enterprise_id);
    this.enterprise = this.rs.enterprises[enterprise_index];
    this.project = this.searchProjectById(enterprise_index,this.rs.project_id);    
    this.reportData.worker_fullname = this.us.user.name;
  }
  ionViewDidEnter() {
    let enterprise_index = this.searchEnterpriseById(this.rs.enterprise_id);
    this.enterprise = this.rs.enterprises[enterprise_index];
    this.project = this.searchProjectById(enterprise_index,this.rs.project_id);  
    this.reportData.worker_fullname = this.us.user.name;
    console.log(this.us.user);

  } 

  saveReport(){
    let date = moment().format("YYYY-MM-DD");
    this.reportData.date_register = date;

    this.cs.sendTemperature(this.reportData)
    .subscribe(
        (data) => {
            if(!data.error){
                this.presentToastWithOptions();
            } else {
                this.alertCtrl.present("TEMPERATURA - JJC",data.msg)
            }

            this.navCtrl.pop();
            this.loading.dismiss();
        },
        (error) => {           
            this.navCtrl.pop();
            
            this.loading.dismiss();

        }
    )
  }
  eventHandler(keyCode: any){
    if(keyCode===13){
      this.saveReport();
    }
  }
  searchEnterpriseById(enterprise_id: any) {
    for (let index = 0; index < this.rs.enterprises.length; index++) {
        const element = this.rs.enterprises[index];
        if (element.id == enterprise_id) {
            return index;
        }
    }

    return -1;
  }
  async presentToastWithOptions() {
    const toast = await this.toastController.create({
        message: 'Registro envíado correctamente',
        position: 'bottom',
        duration: 2000
    });
    toast.present();
}
  searchProjectById(enterprise_index: any,project_id: any)
  {
        let projects = this.rs.enterprises[enterprise_index].projects;
        for (let index = 0; index < projects.length; index++) {
            const element = projects[index];
            if(element.id == project_id) {
                return element;
            }
        }

        return null;
  }


}
