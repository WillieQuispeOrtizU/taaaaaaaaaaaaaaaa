import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RecordService } from 'src/app/services/record.service';
import { LocationService } from 'src/app/services/location.service';
import { AlertController, NavController, Platform } from '@ionic/angular';
import { UserService } from 'src/app/services/user.service';
import { LoadingService } from 'src/app/services/loading.service';
import { NetworkService } from 'src/app/services/network.service';
import { AlertCtrlService } from 'src/app/services/alert-ctrl.service';
import { Enterprise } from 'src/app/interfaces/enterprise';
/* import { InAppBrowser } from '@ionic-native/in-app-browser/ngx'; */
import { Browser } from '@capacitor/browser';
import { Subscription } from 'rxjs';

import { VersionService } from 'src/app/services/version.service';
import { Device } from '@capacitor/device';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-file-main',
  templateUrl: './file-main.page.html',
  styleUrls: ['./file-main.page.scss'],
})
export class FileMainPage implements OnInit {
  project_id:any = '';
  reports:any[] = [];
  covid_records:any[] = [];
  loading_flag:boolean = false;
  version_flag:boolean = false;
  project:any;
  show_corona = false;
  show_corona_card = false;
  segment_records = '0';
  enterprise:Enterprise;
  private networkSubscription!: Subscription;
  constructor(private router: Router,
    public rs: RecordService,
    public ls: LocationService,
    private alertController: AlertController,
    private alertCtrl: AlertCtrlService,
    private loading: LoadingService,
    public us: UserService,
    private navCtrl: NavController,
    private ns: NetworkService,
    private platform: Platform,
    private vs: VersionService) { 
      let enterprise_index = this.searchEnterpriseById(this.rs.enterprise_id);
      this.enterprise = this.rs.enterprises[enterprise_index];
      this.project = this.searchProjectById(enterprise_index,this.rs.project_id);
      const hasConnectionChanged = this.ns.checkConnectionAndResetFlag();

      this.networkSubscription = this.ns.isConnected$.subscribe((isConnected) => {
        if (isConnected && !this.loading_flag && hasConnectionChanged) {
          this.loading_flag = true;
          this.getGeneralInformation();
        }
      });
    }

  ngOnInit() {
  }
  ionViewDidEnter() {
    if(!this.us.user.roles)
    {
        this.logout();
    }
    this.ls.getCurrentLocation();
    this.getGeneralInformation();
    this.ns.initializeNetworkEvents();
   /*  this.events.subscribe('internet_change', (data: any) => {
        if(data){
            if(this.loading_flag)
                return;
            
            this.loading_flag = true;
            this.getGeneralInformation();
        }
    }); */
  }
  ngOnDestroy() {
    // Asegúrate de desuscribirte para evitar posibles fugas de memoria
    this.networkSubscription.unsubscribe();
  }
  logout() {
    this.loading.present();
    this.us.logout()
        .subscribe(
            (data) => {
                this.loading.dismiss();
                this.us.clearAll();
                this.navCtrl.navigateRoot('/login');
            },
            (err) => {
                this.loading.dismiss();
                console.log(err);
            }
        );
  }
  async download(item: any){
    await Browser.open({ url: item.url_image, windowName: '_system', presentationStyle: 'fullscreen' });

    /* this.iab.create(item.url_image, '_system', 'location=yes'); */
  }
  searchEnterpriseById(enterprise_id: any) {
    for (let index = 0; index < this.rs.enterprises.length; index++) {
        const element = this.rs.enterprises[index];
        if (element.id == enterprise_id) {
            return index;
        }
    }

    return -1;
  }
  async goWebFile(){
    Browser.open({ url: 'https://ssomac.jjc.com.pe', windowName: '_blank', presentationStyle: 'fullscreen' });

/*     this.iab.create('https://ssomac.jjc.com.pe', '_blank', 'location=yes'); */
  }
  searchProjectById(enterprise_index: any,project_id: any)
  {
      let projects = this.rs.enterprises[enterprise_index].projects;
      for (let index = 0; index < projects.length; index++) {
          const element = projects[index];
          if(element.id == project_id) {
              return element;
          }
      }

      return null;
  }
  doRefresh(event: any) {
      
    this.getGeneralInformation(event);

  }
  getGeneralInformation(event?: any) {
    if(!this.ns.checkConnection()){
        this.reports = this.rs.reports;
        if(event)
            event.target.complete();

        return;
    } else {
        
       
        let data = {
            pending_reports: null,
            deleted_reports: null
        };

       

        this.getInfo(data,event);
    }
  }
  async getInfo(parameters: any,event?: any) {
    // if(this.loading_flag)
    //     return;

    // this.loading_flag = true;
    this.loading.present();

    this.rs.getUserFiles()
    .subscribe(
        async (data) => {
            if(this.loading.isLoading)
                this.loading.dismiss();
                
            if (event)
                event.target.complete();            
            
            this.reports = data.list_files;         
            const info = await Device.getInfo();
           

            if(info.platform!="web") {
                let version_local = environment.androidVersion;

                let device_name = "android";
                if(!this.platform.is("android")) {
                    version_local = environment.iosVersion;
                    device_name = "ios";
                }

                this.version_flag = true;
                const version_check = await this.vs.compareVersions(version_local,this.rs.version[device_name]);

                // console.log(version_check,version_local,this.rs.version[device_name],device_name);
                if(!version_check) {
                    this.navCtrl.navigateRoot('/update-app');
                    this.version_flag = false;
                }
                // if (!this.version_flag && this.rs.version[device_name] != version_local){
                //     this.version_flag = true;
                //     this.navCtrl.navigateRoot('/update-app');
                //     // this.presentAlertConfirm().then(
                //     //     () => {
                //     //         this.version_flag = false;
                //     //     }
                //     // );
                // }
            }
        },
        (err) => {
            this.loading.dismiss();
            this.loading_flag = false;
            if (event)
                event.target.complete();
            console.log(err);
        }
    )
  }

}
