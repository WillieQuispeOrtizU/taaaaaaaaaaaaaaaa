import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FileMainPage } from './file-main.page';

describe('FileMainPage', () => {
  let component: FileMainPage;
  let fixture: ComponentFixture<FileMainPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FileMainPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileMainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
