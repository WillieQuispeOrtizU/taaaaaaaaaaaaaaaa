import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { LoadingService } from 'src/app/services/loading.service';
import { Router } from '@angular/router';
import { NetworkService } from 'src/app/services/network.service';
import { AlertCtrlService } from 'src/app/services/alert-ctrl.service';
import { NavController } from '@ionic/angular';
import { Device } from '@capacitor/device';


@Component({
    selector: 'app-login',
    templateUrl: './login.page.html',
    styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

    userData = {
        email: '',
        password: ''
    }
    internet_flag = false;
    v = 6;
    bg_container = "none";
    color = "#FFF";
    constructor(private us: UserService,
        private loading: LoadingService,
        private router: Router,
        private ns: NetworkService,
        private alertCtrl: AlertCtrlService,
        private navCtrl: NavController) {
        console.log("LOGIN COSNT")
        // let version = this.device.version;
        // this.v = Number(version.split('.')[0]);

        // if(this.v < 6)
        // {
        //     this.bg_container = '#FFF';
        //     this.color = '#000';
        // }
    }

    ngOnInit() {
        this.internet_flag = this.ns.checkConnection();
        console.log("LOGIN")
    }

    login(event: any) {
        if (!this.ns.checkConnection()) {
            this.alertCtrl.present('Error', 'No tiene conexión a internet');
            console.log("NO INTERNET")
            return;
        }

        this.loading.present();
        this.us.login(this.userData)
            .subscribe(
                (data) => {
                    this.loading.dismiss();

                    if (data.error) {
                        this.us.manageErrors(data, event.target);
                        return;
                    }
                    if (data.type == 0) {
                        this.us.user = data.user;
                        this.us.saveData();

                        if (data.isActive == 0) {
                            this.navCtrl.setDirection('root');
                            this.router.navigate(['/activate-user-code']);
                        } else if (data.isActive == 1) {
                            if (this.userData.password != 'maar') {
                                console.log("linea70")
                                this.navCtrl.setDirection('root');
                                this.router.navigate(['/pre-main']);
                            }
                            else {
                                this.alertCtrl.present('JJC', 'Bienvenido a JJC MAAR, ahora debes cambiar tu contraseña');
                                console.log("linea75")
                                this.navCtrl.setDirection('root');
                                this.router.navigate(['/change-password', { page: 'login' }]);
                            }
                        }
                    }
                },
                (err) => {
                    this.loading.dismiss();
                    console.log(err);
                },
            )
    }
}
