import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ActivateUserPage } from './activate-user.page';
import { ActivateUserPageRoutingModule } from './activate-user-routing.module';

const routes: Routes = [
  {
    path: '',
    component: ActivateUserPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ActivateUserPageRoutingModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ActivateUserPage]
})
export class ActivateUserPageModule {}
