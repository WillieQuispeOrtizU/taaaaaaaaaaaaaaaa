import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { LoadingService } from 'src/app/services/loading.service';
import { Router } from '@angular/router';
import { NetworkService } from 'src/app/services/network.service';
import { AlertCtrlService } from 'src/app/services/alert-ctrl.service';
import { NavController, IonContent, ModalController } from '@ionic/angular';
import { TermsPage } from '../terms/terms.page';
import { NgSignaturePadOptions, SignaturePadComponent } from '@almothafar/angular-signature-pad';


@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  userData = {
    fullName: '',
    dni: '',
    email: '',
    password: '',
    terms: 0,
    code:''
  }
  internet_flag = false;
  v = 6;
  bg_container = "none";
  color = "#FFF";
  flag_canvas: Boolean = false;

  constructor(private us: UserService,
    private loading: LoadingService,
    private router: Router,
    private ns: NetworkService,
    private alertCtrl: AlertCtrlService,
    private navCtrl: NavController,
    private modalCtrl: ModalController) {
    console.log("REGISTER COSNT")
  }

  ngOnInit() {
    this.internet_flag = this.ns.checkConnection();
    console.log("REGISTER")
  }

  async termsLegal() {
    const modal = await this.modalCtrl.create({
      component: TermsPage,
    });
    await modal.present();
  }

  register(event: any) {
    if (!this.ns.checkConnection()) {
      this.alertCtrl.present('Error', 'No tiene conexión a internet');
      console.log("NO INTERNET")
      return;
    }
    if (!this.userData.terms) {
      this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo", "Debes aceptar los términos y condiciones");
      return;
    }
    if (!this.userData.email) {
      this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo", "Debes ingresar un correo");
      return;
    }
    if (!this.userData.dni) {
      this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo", "Debes ingresar tu DNI");
      return;
    }
    if (!this.userData.fullName) {
      this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo", "Debes ingresar tu nombre");
      return;
    }
    if (!this.userData.password) {
      this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo", "Debes ingresar tu contraseña");
      return;
    }
    console.log(this.userData)
    this.us.register(this.userData)
    .subscribe(
        (data) => {
            this.loading.dismiss();

            if (data.error) {
                this.us.manageErrors(data, event.target);
                return;
            }
            if(data.type == 0){
              this.us.user = data.user;
              this.us.activationEmail = this.userData.email; // Guarda email
              this.us.activationCode = data.code; // Guarda Codigo
              this.us.saveData();
            }

            this.navCtrl.setDirection('root');
            this.router.navigate(['/activate-user-code']);

        },
        (err) => {
            this.loading.dismiss();
            console.log(err);
        },
    )
  }
}
