import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { ComponentsModule } from './components/components.module';

import { AngularSignaturePadModule } from '@almothafar/angular-signature-pad';


import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { TokenInterceptor } from './interceptors/token.interceptor';
import { IonicStorageModule } from '@ionic/storage-angular';
import { Geolocation } from '@capacitor/geolocation';
import { Camera } from '@capacitor/camera';
import { Network } from '@capacitor/network';
import { Device } from '@capacitor/device';
/* import { NgxPicaModule } from 'ngx-pica'; */
import { Browser } from '@capacitor/browser';

/* import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
 */
@NgModule({
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    declarations: [AppComponent],
    /* entryComponents: [], */
    imports: [
        BrowserModule, 
        IonicModule.forRoot(), 
        AppRoutingModule,
        HttpClientModule,
        AngularSignaturePadModule,
        IonicStorageModule.forRoot(),
        ComponentsModule,
        /* NgxPicaModule */
    ],
    providers: [
        /* StatusBar,
        SplashScreen, */
        { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: TokenInterceptor,
            multi: true
        },
        /* Geolocation,
        Camera,
        Network,
        Device, */
    ],
    bootstrap: [AppComponent]
})
export class AppModule {}
