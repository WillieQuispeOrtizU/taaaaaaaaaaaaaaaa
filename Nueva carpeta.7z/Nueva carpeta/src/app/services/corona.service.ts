import { Injectable } from '@angular/core';
import { QueryService } from './query.service';
import { Simple } from '../interfaces/general';
import { CardResponse } from '../interfaces/card';

@Injectable({
    providedIn: 'root'
})
export class CoronaService {

    constructor(private query: QueryService) { }

    sendTemperature(data: any) {
        return this.query.executeQuery<Simple>('post', '/saveExamenTarjeta', data);
    }
    sendData(data: any) {
        return this.query.executeQuery<Simple>('post', '/saveInfo', data);
    }

    getCardData() {
        return this.query.executeQuery<CardResponse>('post', '/getCard', {});
    }
}
