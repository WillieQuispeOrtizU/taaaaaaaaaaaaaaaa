import { Injectable } from '@angular/core';
import { Platform, NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage-angular';
import { environment } from 'src/environments/environment';
import { UserAnswer } from '../interfaces/login';
import { AlertCtrlService } from './alert-ctrl.service';
import { QueryService } from './query.service';
import { Simple } from '../interfaces/general';
import { RecordService } from './record.service';
import { Device } from '@capacitor/device';
import { UserAnswerRegister } from '../interfaces/register';

const apiUrl = environment.apiUrl;

@Injectable({
    providedIn: 'root'
})
export class UserService {
    activationCode: number = 0;
    activationEmail:  string = '';
    user: any = undefined;
    constructor(private platform: Platform,
                private storage: Storage,
                private qs: QueryService,
                private alertCtrl: AlertCtrlService,
                private navCtrl: NavController,
                private rs: RecordService
                ) {
        this.loadStorage();
    }

    login(userData: any) {
        return this.qs.executeQuery<UserAnswer>('post', '/login', userData);
    }

    register(userData: any) {
        return this.qs.executeQuery<UserAnswerRegister>('post', '/register', userData);
    }

    checkUserActivate() {
        return this.qs.executeQuery<UserAnswer>('get', '/checkUser', {});
    }

    changePassword(data: any) {
        return this.qs.executeQuery<Simple>('post', '/changePassword', data);
    }

    recoverPass(data: any) {
        return this.qs.executeQuery<Simple>('post', '/recoverPass', data);
    }

    logout() {
        return this.qs.executeQuery<Simple>('post', '/logout', {});
    }

    async checkUser() {
        await this.loadStorage();

        if (this.user == undefined) {
            this.navCtrl.navigateRoot('/login');
            return Promise.resolve(false);
        }

        return Promise.resolve(true);
    }

    async checkUserStatus() {

        console.log(Number(this.user.status) == 0);
        console.log(this.user);
        if (Number(this.user.status) == 0) {
            this.navCtrl.navigateRoot('/activate-user');
            return Promise.resolve(false);
        }

        return Promise.resolve(true);
    }

    async clearAll() {
        const info = await Device.getInfo();

        if (info.platform!="web") {
            this.storage.create()
                .then(() => {
                    this.storage.clear();
                    this.user = {};
                    this.rs.enterprise_id = "";
                    this.rs.project_id = "";
                    this.rs.projects = [];
                    this.rs.enterprises = [];
                    this.rs.categories = [];
                    this.rs.risks = [];
                    this.rs.reports = [];
                    this.rs.version = {};
                    // this.rs.saveData();
                })
        } else {
            localStorage.clear();
            this.user = {};
            this.rs.enterprise_id = "";
            this.rs.project_id = "";
            this.rs.projects = [];
            this.rs.enterprises = [];
            this.rs.categories = [];
            this.rs.risks = [];
            this.rs.reports = [];
            this.rs.version = {};
        }
    }

    manageErrors(data_resp: any, form: any = null) {
        let msg = data_resp.msg;
        if (data_resp.error) {
            if (data_resp.msgs) {
                msg = "";
                for (let m in data_resp.msgs) {
                    if (form !== null) {
                        let elem = form.getElementsByClassName(m + "-errors");

                        if (elem[0]) {
                            elem[0].innerHTML = data_resp.msgs[m];
                        }
                    }

                    msg += ". " + data_resp.msgs[m];
                }
                msg = msg.substr(2);
            }
        }

        this.alertCtrl.present("JJC", msg);
    }


    saveData() {
        this.saveStorage();
    }

    saveCode() {
      localStorage.setItem('user', JSON.stringify(this.user));
    }
    saveEmail() {
      localStorage.setItem('user', JSON.stringify(this.user));
    }

    private async saveStorage() {
        const info = await Device.getInfo();

        if (info.platform!="web") {
            this.storage.set('user', this.user);
        } else {
            localStorage.setItem("user", JSON.stringify(this.user));
        }
    }

    async loadStorage() {
        const info = await Device.getInfo();

        let promesa = new Promise<void>((resolve, reject) => {
            if (info.platform!="web") {
                this.storage.create()
                    .then(() => {
                        this.storage.get("user")
                            .then(user => {
                                if (user) {
                                    this.user = user;
                                }
                                resolve();
                            });
                    })
            } else {
                if (localStorage.getItem("user")) {
                    this.user = JSON.parse(localStorage.getItem("user")!);
                }
                resolve();
            }
        });
        return promesa;
    }
}
