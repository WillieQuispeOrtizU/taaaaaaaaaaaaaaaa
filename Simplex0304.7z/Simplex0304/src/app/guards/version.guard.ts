import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanLoad } from '@angular/router';
import { Observable } from 'rxjs';
import { VersionService } from '../services/version.service';

@Injectable({
  providedIn: 'root'
})
export class VersionGuard implements CanLoad  {
  
    constructor(private vs: VersionService) { }

    canLoad(): Observable<boolean> | Promise<boolean> | boolean {
        return this.vs.checkCurrentVersion();
    }
}
