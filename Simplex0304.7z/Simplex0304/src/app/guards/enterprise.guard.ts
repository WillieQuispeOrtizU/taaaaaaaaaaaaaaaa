import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanLoad, CanActivate } from '@angular/router';
import { Observable } from 'rxjs';
import { RecordService } from '../services/record.service';

@Injectable({
  providedIn: 'root'
})
export class EnterpriseGuard implements CanLoad, CanActivate {
 
    constructor(private rs: RecordService) { }

    canLoad(): Observable<boolean> | Promise<boolean> | boolean {
        return this.rs.checkPreSelect();
    }

    canActivate(): Observable<boolean> | Promise<boolean> | boolean {
        return this.rs.checkPreSelect();
    }
}
