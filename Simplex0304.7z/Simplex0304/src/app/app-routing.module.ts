import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { EnterpriseGuard } from './guards/enterprise.guard';
import { ActivateUserGuard } from './guards/activate-user.guard';
import { VersionGuard } from './guards/version.guard';

const routes: Routes = [
  { path: '', redirectTo: 'main', pathMatch: 'full' },
  {
      path: 'main',
      loadChildren: () => import('./pages/main/main.module').then(m => m.MainPageModule),
      canLoad: [AuthGuard, EnterpriseGuard]
  },
  {
    path: 'terms',
    loadChildren: () => import('./pages/terms/terms.module').then(m => m.TermsPageModule),
    canLoad: [VersionGuard, AuthGuard]
  },
  {
    path: 'register',
    loadChildren: () => import('./pages/register/register.module').then(m => m.RegisterPageModule),
    canLoad: [VersionGuard]
  },
  {
      path: 'record',
      loadChildren: () => import('./pages/record/record.module').then(m => m.RecordPageModule),
      canLoad: [VersionGuard, AuthGuard]
  },
  {
      path: 'photos',
      loadChildren: () => import('./pages/photos/photos.module').then(m => m.PhotosPageModule),
      canLoad: [VersionGuard, AuthGuard]
  },
  {
      path: 'login',
      loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule),
      canLoad: [VersionGuard]
  },
  {
      path: 'pre-main',
      loadChildren: () => import('./pages/pre-main/pre-main.module').then(m => m.PreMainPageModule),
      canLoad: [VersionGuard, AuthGuard]
  },
  {
      path: 'profile',
      loadChildren: () => import('./pages/profile/profile.module').then(m => m.ProfilePageModule),
      canLoad: [VersionGuard, AuthGuard]
  },
  {
      path: 'recover-pass',
      loadChildren: () => import('./pages/recover-pass/recover-pass.module').then(m => m.RecoverPassPageModule),
      canLoad: [VersionGuard]
  },
  {
      path: 'change-password',
      loadChildren: () => import('./pages/change-password/change-password.module').then(m => m.ChangePasswordPageModule),
      canLoad: [VersionGuard, AuthGuard],
  },
  {
      path: 'activate-user',
      loadChildren: () => import('./pages/activate-user/activate-user.module').then(m => m.ActivateUserPageModule),
      canLoad: [VersionGuard, AuthGuard]
  },
  {
      path: 'corona',
      loadChildren: () => import('./pages/corona/corona.module').then(m => m.CoronaPageModule),
      canLoad: [VersionGuard, AuthGuard]
  },
  {
      path: 'update-app',
      loadChildren: () => import('./pages/update-app/update-app.module').then(m => m.UpdateAppPageModule),
  },
  { path: 'corona-card', loadChildren: () => import('./pages/corona-card/corona-card.module').then(m => m.CoronaCardPageModule) },
  { path: 'tarjeta-main', loadChildren: () => import('./pages/tarjeta-main/tarjeta-main.module').then(m => m.TarjetaMainPageModule) },
  { path: 'ficha-main', loadChildren: () => import('./pages/ficha-main/ficha-main.module').then(m => m.FichaMainPageModule) },
  { path: 'temperature-card', loadChildren: () => import('./pages/temperature-card/temperature-card.module').then(m => m.TemperatureCardPageModule) },
  { path: 'file-main', loadChildren: () => import('./pages/file-main/file-main.module').then(m => m.FileMainPageModule) },
];


@NgModule({
    imports: [
        RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
    ],
    exports: [RouterModule]
})
export class AppRoutingModule { }
