export interface RecordAnswer {
    error: boolean;
    record: Record;
}

export interface Record {
    id: number;
    project_id: number;
    category_id: number;
    type: string;
    area: string;
    completed: Date;
    latitude: string;
    longitude: string;
    worker_fullname: string;
    worker_id_number: string;
    description?: any;
    suggestions?: any;
    boss_signature: string;
    boss_fullname: string;
    url_front: string;
    url_back: string;
    risks_list: number[];
    project: Project;
    created_at?: Date;
    uuid?: String;
}

export interface Project {
    id: number;
    enterprise_id: number;
    name: string;
}