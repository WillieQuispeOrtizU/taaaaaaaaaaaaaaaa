import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { LoadingService } from 'src/app/services/loading.service';
import { Router } from '@angular/router';
import { NetworkService } from 'src/app/services/network.service';
import { AlertCtrlService } from 'src/app/services/alert-ctrl.service';
import { NavController, IonContent, ModalController} from '@ionic/angular';
import { Device } from '@capacitor/device';
import { TermsPage } from '../terms/terms.page';

@Component({
    selector: 'app-register',
    templateUrl: './register.page.html',
    styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

    userData = {
        fullName:'',
        routerDirection:'',
        dni:'',
        email:'',
        password:'',
        signature:'',
        terms:0
    }
    internet_flag = false;
    v = 6;
    bg_container = "none";
    color = "#FFF";
    constructor(private us: UserService,
                private loading: LoadingService,
                private router: Router,
                private ns: NetworkService,
                private alertCtrl: AlertCtrlService,
                private navCtrl: NavController,
                private modalCtrl: ModalController) {
                    console.log("REGISTER COSNT")
        // let version = this.device.version;
        // this.v = Number(version.split('.')[0]);

        // if(this.v < 6)
        // {
        //     this.bg_container = '#FFF';
        //     this.color = '#000';
        // }
    }

    ngOnInit() {
        this.internet_flag = this.ns.checkConnection();
        console.log("REGISTER")
    }
    async termsLegal() {
        const modal = await this.modalCtrl.create({
            component: TermsPage,
        });
        await modal.present();
    }

    register(event: any) {
        if(!this.ns.checkConnection())
        {
            this.alertCtrl.present('Error','No tiene conexión a internet');
            console.log("NO INTERNET")
            return;
        }
        if (!this.userData.terms) {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes aceptar los términos y condiciones");
            return;
        }
        if (this.userData.signature == '') {
            this.alertCtrl.present("MAAR - Me Anticipo Al Riesgo","Debes poner tu firma");
            return;
        }
        this.loading.present();
        this.us.register(this.userData)
            .subscribe(
                (data) => {
                    this.loading.dismiss();
                    if (data.error) {
                        this.us.manageErrors(data, event.target);
                        return;
                    }

                    this.us.user = data.user;
                    this.us.saveData();

                    this.navCtrl.setDirection('root');
                    this.router.navigate(['/login']);
                    
                },
                (err) => {
                    this.loading.dismiss();
                    console.log(err);
                },
            )
    }
}
