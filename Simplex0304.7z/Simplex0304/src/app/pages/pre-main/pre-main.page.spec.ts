import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PreMainPage } from './pre-main.page';

describe('PreMainPage', () => {
  let component: PreMainPage;
  let fixture: ComponentFixture<PreMainPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(PreMainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
