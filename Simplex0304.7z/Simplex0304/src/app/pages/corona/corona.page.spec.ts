import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CoronaPage } from './corona.page';

describe('CoronaPage', () => {
  let component: CoronaPage;
  let fixture: ComponentFixture<CoronaPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(CoronaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
