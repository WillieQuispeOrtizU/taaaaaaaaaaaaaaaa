import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CoronaCardPage } from './corona-card.page';

describe('CoronaCardPage', () => {
  let component: CoronaCardPage;
  let fixture: ComponentFixture<CoronaCardPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(CoronaCardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
