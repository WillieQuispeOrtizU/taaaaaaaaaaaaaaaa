export const environment = {
  production: true,
  apiUrl:'https://ssomac.jjc.com.pe/api',
  androidVersion: '0.5.2',
  iosVersion: '0.5.1'
};
